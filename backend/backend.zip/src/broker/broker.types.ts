export interface BrokerMicroserviceConfig {
  queue: string;
  subscriptions: string[];
}
