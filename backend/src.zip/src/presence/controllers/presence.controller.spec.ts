import { Test, TestingModule } from '@nestjs/testing';
import { PresenceController } from './presence.controller';
import { GetOnlineHandler } from '../handlers/get-online.handler';
import { PublishOnlineHandler } from '../handlers/publish-online.handler';
import { PublishOfflineHandler } from '../handlers/publish-offline.handler';
import { BadRequestException } from '@nestjs/common';

describe('PresenceController', () => {
  let controller: PresenceController;
  let getOnlineHandler: GetOnlineHandler;
  let publishOnlineHandler: PublishOnlineHandler;
  let publishOfflineHandler: PublishOfflineHandler;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PresenceController],
      providers: [
        {
          provide: GetOnlineHandler,
          useValue: { execute: jest.fn().mockResolvedValue(['user1', 'user2']) },
        },
        {
          provide: PublishOnlineHandler,
          useValue: { execute: jest.fn().mockResolvedValue({ ok: true }) },
        },
        {
          provide: PublishOfflineHandler,
          useValue: { execute: jest.fn().mockResolvedValue({ ok: true }) },
        },
      ],
    }).compile();

    controller = module.get<PresenceController>(PresenceController);
    getOnlineHandler = module.get<GetOnlineHandler>(GetOnlineHandler);
    publishOnlineHandler = module.get<PublishOnlineHandler>(PublishOnlineHandler);
    publishOfflineHandler = module.get<PublishOfflineHandler>(PublishOfflineHandler);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should get online users', async () => {
    const result = await controller.getOnline();
    expect(result).toEqual(['user1', 'user2']);
    expect(getOnlineHandler.execute).toHaveBeenCalledWith({});
  });

  it('should publish user as online', async () => {
    const body = { userId: 'abc123' };
    const result = await controller.publish(body);
    expect(result).toEqual({ ok: true });
    expect(publishOnlineHandler.execute).toHaveBeenCalledWith({ userId: 'abc123' });
  });

  it('should throw BadRequest if publish called without userId', async () => {
    await expect(controller.publish({})).rejects.toThrow(BadRequestException);
    await expect(controller.publish({ userId: '' })).rejects.toThrow(BadRequestException);
  });

  it('should publish user as offline', async () => {
    const body = { userId: 'xyz789' };
    const result = await controller.offline(body);
    expect(result).toEqual({ ok: true });
    expect(publishOfflineHandler.execute).toHaveBeenCalledWith({ userId: 'xyz789' });
  });

  it('should throw BadRequest if offline called without userId', async () => {
    await expect(controller.offline({})).rejects.toThrow(BadRequestException);
    await expect(controller.offline({ userId: '  ' })).rejects.toThrow(BadRequestException);
  });
});
