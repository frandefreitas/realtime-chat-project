import 'reflect-metadata'
import { Test } from '@nestjs/testing'
import { getModelToken } from '@nestjs/mongoose'
import { ListUsersHandler } from './list-users.handler'
import { User } from '../schemas/user.schema'

describe('ListUsersHandler', () => {
  let handler: ListUsersHandler
  let modelMock: any

  beforeEach(async () => {
    modelMock = { find: jest.fn() }

    const moduleRef = await Test.createTestingModule({
      providers: [
        ListUsersHandler,
        { provide: getModelToken(User.name), useValue: modelMock },
      ],
    }).compile()

    handler = moduleRef.get(ListUsersHandler)
  })

  it('lista usuários', async () => {
    modelMock.find.mockResolvedValue([{ _id: '1', username: 'a' }, { _id: '2', username: 'b' }])
    const res = await handler.execute({})
    expect(res.users).toHaveLength(2)
  })
})
