import 'reflect-metadata'
import { Test } from '@nestjs/testing'
import { getModelToken } from '@nestjs/mongoose'
import { NotFoundException } from '@nestjs/common'
import { GetUserByIdHandler } from './get-user-by-id.handler'
import { User } from '../schemas/user.schema'

describe('GetUserByIdHandler', () => {
  let handler: GetUserByIdHandler
  let modelMock: any

  beforeEach(async () => {
    modelMock = { findById: jest.fn() }

    const moduleRef = await Test.createTestingModule({
      providers: [
        GetUserByIdHandler,
        { provide: getModelToken(User.name), useValue: modelMock },
      ],
    }).compile()

    handler = moduleRef.get(GetUserByIdHandler)
  })

  it('retorna usuário existente', async () => {
    modelMock.findById.mockResolvedValue({ _id: '651111111111111111111111', name: 'Alice', toObject: undefined })
    const res = await handler.execute({ id: '651111111111111111111111' })
    expect(res.user.name).toBe('Alice')
  })

  it('lança se id inválido', async () => {
    await expect(handler.execute({ id: 'bad' })).rejects.toBeInstanceOf(NotFoundException)
  })

  it('lança se não encontrar', async () => {
    modelMock.findById.mockResolvedValue(null)
    await expect(handler.execute({ id: '651111111111111111111111' })).rejects.toBeInstanceOf(NotFoundException)
  })
})
