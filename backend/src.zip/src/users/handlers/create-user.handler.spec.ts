import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { CreateUserHandler } from './create-user.handler';
import { User } from '../schemas/user.schema';
import { BadRequestException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

describe('CreateUserHandler', () => {
  let handler: CreateUserHandler;
  let userModel: any;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CreateUserHandler,
        {
          provide: getModelToken(User.name),
          useValue: {
            findOne: jest.fn(),
            save: jest.fn(),
          },
        },
      ],
    }).compile();

    handler = module.get<CreateUserHandler>(CreateUserHandler);
    userModel = module.get(getModelToken(User.name));
  });

  it('should be defined', () => {
    expect(handler).toBeDefined();
  });

  it('should throw if required fields are missing', async () => {
    await expect(handler.execute({} as any)).rejects.toThrow(BadRequestException);
    await expect(handler.execute({ username: '', email: '', password: '' })).rejects.toThrow(BadRequestException);
  });

  it('should throw if username or email is already in use', async () => {
    userModel.findOne = jest.fn().mockResolvedValueOnce({ _id: 'exists' });

    await expect(
      handler.execute({ username: 'joao', email: 'joao@mail.com', password: '123' }),
    ).rejects.toThrow(BadRequestException);
  });

  it('should create user successfully and return sanitized object', async () => {
    userModel.findOne = jest.fn().mockResolvedValueOnce(null);

    const saveMock = jest.fn().mockResolvedValue(undefined);
    const toObjectMock = jest.fn().mockReturnValue({
      _id: 'abc123',
      username: 'joao',
      email: 'joao@mail.com',
      password: 'shouldBeRemoved',
    });

    userModel.mockImplementation = jest.fn().mockImplementation((data) => ({
      ...data,
      save: saveMock,
      toObject: toObjectMock,
    }));

    const hashed = await bcrypt.hash('123456', 10);
    jest.spyOn(bcrypt, 'hash').mockResolvedValue(hashed);

    const handlerWithMock = new CreateUserHandler({
      findOne: userModel.findOne,
      save: jest.fn(),
      ...userModel,
      constructor: function () {},
      prototype: {},
    } as any);

    (handlerWithMock as any).userModel = function (this: any, data: any) {
      return {
        ...data,
        save: saveMock,
        toObject: toObjectMock,
      };
    } as any;

    const result = await handlerWithMock.execute({
      username: 'joao',
      email: 'joao@mail.com',
      password: '123456',
    });

    expect(saveMock).toHaveBeenCalled();
    expect(toObjectMock).toHaveBeenCalled();
    expect(result.password).toBeUndefined();
    expect(result.username).toBe('joao');
  });
});
