import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { JwtService } from '@nestjs/jwt';
import { ConflictException } from '@nestjs/common';
import { RegisterHandler } from './register.handler';
import { User } from '@/users/schemas/user.schema';

describe('RegisterHandler', () => {
  let handler: RegisterHandler;
  let userModel: any;
  let jwtService: JwtService;

  const dto = {
    username: 'testuser',
    email: 'test@example.com',
    password: 'plainpass',
    name: 'Test',
    role: 'client',
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        RegisterHandler,
        {
          provide: getModelToken(User.name),
          useValue: {
            findOne: jest.fn(),
            create: jest.fn(),
          },
        },
        {
          provide: JwtService,
          useValue: {
            sign: jest.fn().mockReturnValue('mocked-jwt-token'),
          },
        },
      ],
    }).compile();

    handler = module.get<RegisterHandler>(RegisterHandler);
    userModel = module.get(getModelToken(User.name));
    jwtService = module.get<JwtService>(JwtService);
  });

  it('should be defined', () => {
    expect(handler).toBeDefined();
  });

  it('should register user and return token', async () => {
    const createdUser = {
      _id: 'user123',
      username: dto.username,
      email: dto.email,
    };

    userModel.findOne
      .mockImplementationOnce(() => ({ lean: () => null })) // username not found
      .mockImplementationOnce(() => ({ lean: () => null })); // email not found

    userModel.create.mockResolvedValueOnce(createdUser);

    const result = await handler.execute(dto);

    expect(result).toEqual({ access_token: 'mocked-jwt-token' });
    expect(userModel.create).toHaveBeenCalled();
    expect(jwtService.sign).toHaveBeenCalledWith({
      sub: 'user123',
      username: 'testuser',
    });
  });

  it('should throw if username is taken', async () => {
    userModel.findOne.mockImplementationOnce(() => ({ lean: () => ({ username: 'testuser' }) }));

    await expect(handler.execute(dto)).rejects.toThrow(ConflictException);
  });

  it('should throw if email is already in use', async () => {
    userModel.findOne
      .mockImplementationOnce(() => ({ lean: () => null }))
      .mockImplementationOnce(() => ({ lean: () => ({ email: 'test@example.com' }) }));

    await expect(handler.execute(dto)).rejects.toThrow(ConflictException);
  });
});
