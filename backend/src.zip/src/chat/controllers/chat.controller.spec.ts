import { Test, TestingModule } from '@nestjs/testing';
import { ChatController } from './chat.controller';
import { SendDirectHandler } from '../handlers/send-direct.handler';
import { GetHistoryHandler } from '../handlers/get-history.handler';

describe('ChatController', () => {
  let controller: ChatController;
  let sendDirect: SendDirectHandler;
  let getHistory: GetHistoryHandler;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ChatController],
      providers: [
        {
          provide: SendDirectHandler,
          useValue: { execute: jest.fn() },
        },
        {
          provide: GetHistoryHandler,
          useValue: { execute: jest.fn() },
        },
      ],
    }).compile();

    controller = module.get<ChatController>(ChatController);
    sendDirect = module.get<SendDirectHandler>(SendDirectHandler);
    getHistory = module.get<GetHistoryHandler>(GetHistoryHandler);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should send message using SendDirectHandler', async () => {
    const body = { from: 'a1', to: 'b1', text: 'Hello' };
    const result = { ok: true as true };

    jest.spyOn(sendDirect, 'execute').mockResolvedValueOnce(result);

    const response = await controller.send(body);
    expect(response).toEqual(result);
    expect(sendDirect.execute).toHaveBeenCalledWith(body);
  });

  it('should get message history using GetHistoryHandler', async () => {
    const a = 'user1';
    const b = 'user2';
    const limit = '50';
    const before = '1696500000000';
    const result = { msgs: [{ from: a, to: b, text: 'msg' }] };

    jest.spyOn(getHistory, 'execute').mockResolvedValueOnce(result);

    const response = await controller.history(a, b, limit, before);
    expect(response).toEqual(result);
    expect(getHistory.execute).toHaveBeenCalledWith({
      a,
      b,
      limit: 50,
      before: 1696500000000,
    });
  });

  it('should handle history without before param', async () => {
    const a = 'user1';
    const b = 'user2';
    const limit = '20';
    const result = { msgs: [] };

    jest.spyOn(getHistory, 'execute').mockResolvedValueOnce(result);

    const response = await controller.history(a, b, limit);
    expect(response).toEqual(result);
    expect(getHistory.execute).toHaveBeenCalledWith({
      a,
      b,
      limit: 20,
      before: undefined,
    });
  });
});
